================================================================
叠层与层压顺序说明  /  Stack-up & Lamination Order
板名 Board: tourbox eltie
================================================================
层数 Layers .............. 4 层 / 4-Layer
成品板厚 Thickness ....... 1.59 mm +/-10%
叠层代号 Stack-up ........ JLC04161H-7628 (等效: PP 7628 x1 + core 1.065mm + PP 7628 x1, 总 1.6mm)
外层铜 Outer Cu .......... 1 oz (0.035 mm)
内层铜 Inner Cu .......... 0.5 oz (H/HOZ, 0.0152 mm)
最小孔径 Min Hole ........ 0.30 mm   (过孔 0.30mm 钻 / 0.40mm 外径)
最小线宽 Min Trace ....... 0.127 mm (5 mil)
最小间距 Min Spacing ..... 0.152 mm (6 mil)

压合顺序 Lamination (从上到下 / top -> bottom):
        TOP  -  GND  -  VCC  -  BOTTOM
        (中间线路1 = GND 平面, 紧贴 TOP; 中间线路2 = VCC 平面, 紧贴 BOTTOM)

层文件对应 / Layer files:
   L1 顶层线路  TOP          = Gerber_TopLayer.GTL
   L2 内层线路1 (GND 平面)    = Gerber_InnerLayer1.G1
   L3 内层线路2 (VCC 平面)    = Gerber_InnerLayer2.G2
   L4 底层线路  BOTTOM       = Gerber_BottomLayer.GBL
   板框/挖槽 Board outline   = Gerber_BoardOutlineLayer.GKO
   钻孔 Drill               = Drill_PTH_Through.DRL / Drill_NPTH_Through.DRL / Drill_PTH_Through_Via.DRL

重要 IMPORTANT:
  * 内层1(G1) 必须紧贴 TOP, 内层2(G2) 必须紧贴 BOTTOM —— 不可互换。
    原因: 顶层 1000+ 条走线(含 2.4G 天线馈线)以紧贴顶层的那块内层为参考面, 该层必须是 GND。
  * 阻抗 Impedance: TOP 层单端 50 ohm, 参考 INNER_1(GND), 馈线线宽 0.255mm, 两侧共面地间距 0.3mm。
  * 挖槽 Cutout: 8 点闭合轮廓, 位于板左上区域(详见 BoardOutlineLayer)。
================================================================
